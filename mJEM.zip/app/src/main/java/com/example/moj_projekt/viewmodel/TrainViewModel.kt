package com.example.moj_projekt.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moj_projekt.database.Train
import com.example.moj_projekt.repository.AppRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TrainViewModel @Inject constructor(private val repository: AppRepository) : ViewModel() {

    private val _foundTrain = MutableStateFlow<Train?>(null)
    val foundTrain = _foundTrain.asStateFlow()

    fun searchTrainByNumber(number: String) {
        viewModelScope.launch {
            Log.d("TrainViewModel", "Searching train by number: $number")
            _foundTrain.value = repository.database.trainDao().getTrainByNumber(number)
            Log.d("TrainViewModel", "Found train: ${_foundTrain.value}")
        }
    }

    fun searchTrainByRoute(from: String, to: String) {
        viewModelScope.launch {
            Log.d("TrainViewModel", "Searching train by route: $from to $to")
            _foundTrain.value = repository.database.trainDao().getTrainByRoute(from, to)
            Log.d("TrainViewModel", "Found train: ${_foundTrain.value}")
        }
    }

    fun clearFoundTrain() {
        _foundTrain.value = null
    }

    private val _currentTrain = MutableStateFlow<Train?>(null)
    val currentTrain = _currentTrain.asStateFlow()

    fun loadTrain(trainId: Long) {
        viewModelScope.launch {
            _currentTrain.value = repository.database.trainDao().getTrainById(trainId)
        }
    }
}