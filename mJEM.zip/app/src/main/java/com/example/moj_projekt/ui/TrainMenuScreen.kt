package com.example.moj_projekt.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.moj_projekt.database.MenuItem
import com.example.moj_projekt.viewmodel.MenuViewModel
import com.example.moj_projekt.viewmodel.TrainViewModel
import androidx.compose.material3.TopAppBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrainMenuScreen(trainId: Long, onBack: () -> Unit) {
    val viewModel: MenuViewModel = hiltViewModel()
    val trainViewModel: TrainViewModel = hiltViewModel()

    val categories = listOf("Przystawki", "Dania główne", "Napoje")
    var selectedCategory by remember { mutableStateOf(categories[0]) }
    val menuItems by viewModel.getMenuForTrain(trainId).collectAsState(initial = emptyList())

    LaunchedEffect(trainId) {
        trainViewModel.loadTrain(trainId)
    }

    val train by trainViewModel.currentTrain.collectAsState()

    Column {
        TopAppBar(
            title = { Text("Menu pociągu") },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, "Wstecz")
                }
            }
        )

        train?.let {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "${it.trainNumber} - ${it.trainName}",
                    style = MaterialTheme.typography.headlineSmall
                )
                Text(
                    text = "${it.departureCity} → ${it.arrivalCity}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        ScrollableTabRow(selectedTabIndex = categories.indexOf(selectedCategory)) {
            categories.forEach { category ->
                Tab(
                    selected = category == selectedCategory,
                    onClick = { selectedCategory = category }
                ) {
                    Text(category, modifier = Modifier.padding(16.dp))
                }
            }
        }

        LazyColumn {
            items(menuItems.filter { it.category == selectedCategory }) { item ->
                MenuItemRow(item = item, onOrder = {
                    viewModel.decreaseQuantity(item)
                })
            }
        }
    }
}

@Composable
fun MenuItemRow(item: MenuItem) {
    Row(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        Text(item.name, style = MaterialTheme.typography.bodyLarge)
        Spacer(modifier = Modifier.weight(1f))
        Text("Ilość: ${item.availableQuantity}", style = MaterialTheme.typography.bodyMedium)
    }
}