package com.example.moj_projekt.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.moj_projekt.database.MenuItem
import com.example.moj_projekt.repository.AppRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MenuViewModel @Inject constructor(private val repository: AppRepository) : ViewModel() {

    fun getMenuForTrain(trainId: Long): Flow<List<MenuItem>> {
        return repository.database.menuItemDao().getMenuForTrain(trainId)
    }

    fun decreaseQuantity(item: MenuItem) {
        if (item.availableQuantity > 0) {
            val updatedItem = item.copy(availableQuantity = item.availableQuantity - 1)
            viewModelScope.launch {
                repository.database.menuItemDao().updateMenuItem(updatedItem)
            }
        }
    }
}