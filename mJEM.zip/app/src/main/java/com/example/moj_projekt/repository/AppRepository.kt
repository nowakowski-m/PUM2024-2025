package com.example.moj_projekt.repository

import android.util.Log
import com.example.moj_projekt.database.MenuItem
import com.example.moj_projekt.database.Train
import com.example.moj_projekt.database.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class AppRepository @Inject constructor(val database: AppDatabase) {

    suspend fun seedData() = withContext(Dispatchers.IO) {
        val existingTrain = database.trainDao().getTrainByNumber("IC123")
        if (existingTrain == null) {
            val train1 = Train(
                trainNumber = "IC123",
                trainName = "Einstein",
                departureCity = "Warszawa",
                arrivalCity = "Kraków"
            )
            val train1Id = database.trainDao().insertTrain(train1)

            val train2 = Train(
                trainNumber = "IC456",
                trainName = "Curie",
                departureCity = "Gdańsk",
                arrivalCity = "Wrocław"
            )
            val train2Id = database.trainDao().insertTrain(train2)

            listOf(train1Id, train2Id).forEach { trainId ->
                for (i in 1..50) {
                    val category = when {
                        i <= 10 -> "Przystawki"
                        i <= 30 -> "Dania główne"
                        else -> "Napoje"
                    }

                    val menuItem = MenuItem(
                        trainId = trainId,
                        category = category,
                        name = "Produkt $i",
                        description = "Opis produktu $i",
                        imageResName = "img_$i.jpg",
                        availableQuantity = 1
                    )
                    database.menuItemDao().insertMenuItem(menuItem)
                }
            }

            Log.d("SEED_DATA", "Dodano menu dla 2 pociągów")
        }
    }
}
