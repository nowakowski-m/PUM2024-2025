package com.example.moj_projekt.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface TrainDao {
    @Query("SELECT * FROM trains WHERE trainNumber = :number LIMIT 1")
    suspend fun getTrainByNumber(number: String): Train?

    @Query("SELECT * FROM trains WHERE departureCity = :from AND arrivalCity = :to LIMIT 1")
    suspend fun getTrainByRoute(from: String, to: String): Train?

    @Insert
    suspend fun insertTrain(train: Train): Long

    @Query("SELECT * FROM trains WHERE id = :trainId LIMIT 1")
    suspend fun getTrainById(trainId: Long): Train?
}

