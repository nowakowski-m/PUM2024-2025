package com.example.moj_projekt.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trains")
data class Train(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val trainNumber: String,
    val trainName: String,
    val departureCity: String,
    val arrivalCity: String
)
