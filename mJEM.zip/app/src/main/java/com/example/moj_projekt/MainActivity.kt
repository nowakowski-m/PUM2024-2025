package com.example.moj_projekt

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.moj_projekt.ui.TrainMenuScreen
import com.example.moj_projekt.ui.TrainSearchScreen
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            var selectedTrain by remember { mutableStateOf<Long?>(null) }

            if (selectedTrain == null) {
                TrainSearchScreen(onTrainFound = { trainId ->
                    Log.d("MainActivity", "Train found with ID: $trainId")
                    selectedTrain = trainId
                })
            } else {
                Log.d("MainActivity", "Navigating to TrainMenuScreen with train ID: $selectedTrain")
                TrainMenuScreen(
                    trainId = selectedTrain!!,
                    onBack = { selectedTrain = null }
                )
            }
        }
    }
}