package com.example.moj_projekt.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF871ABD)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFF4AAFF)

val Purple40 = Color(0xFF6A129F)
val PurpleGrey40 = Color(0xFF625B71)
val Pink40 = Color(0xFF7D5260)