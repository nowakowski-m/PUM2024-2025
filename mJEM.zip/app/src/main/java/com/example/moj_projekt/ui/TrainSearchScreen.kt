package com.example.moj_projekt.ui

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.moj_projekt.R
import com.example.moj_projekt.viewmodel.TrainViewModel

@Composable
fun TrainSearchScreen(viewModel: TrainViewModel = hiltViewModel(), onTrainFound: (Long) -> Unit) {
    var trainNumber by remember { mutableStateOf("") }
    var from by remember { mutableStateOf("") }
    var to by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = "Logo aplikacji",
            modifier = Modifier
                .size(200.dp)
                .padding(bottom = 46.dp)
        )

        Text("Podaj numer pociągu:", Modifier.align(Alignment.Start))

        OutlinedTextField(
            value = trainNumber,
            onValueChange = { trainNumber = it },
            label = { Text("Numer pociągu") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(38.dp))

        Text("Lub podaj relację:", Modifier.align(Alignment.Start))
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = from,
            onValueChange = { from = it },
            label = { Text("Skąd") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = to,
            onValueChange = { to = it },
            label = { Text("Dokąd") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                errorMessage = null
                when {
                    trainNumber.isNotBlank() -> viewModel.searchTrainByNumber(trainNumber)
                    from.isNotBlank() && to.isNotBlank() -> viewModel.searchTrainByRoute(from, to)
                    else -> errorMessage = "Podaj numer pociągu lub relację (skąd i dokąd)"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Szukaj")
        }

        errorMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        LaunchedEffect(viewModel) {
            viewModel.foundTrain.collect { train ->
                train?.let {
                    Log.d("NAVIGATION", "Przekazano trainId: ${it.id}, numer: ${it.trainNumber}")
                    onTrainFound(it.id)
                    viewModel.clearFoundTrain()
                }
            }
        }
    }
}