package com.example.moj_projekt.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "menu_items")
data class MenuItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val trainId: Long,
    val category: String,
    val name: String,
    val description: String,
    val imageResName: String,
    val availableQuantity: Int = 1
)
